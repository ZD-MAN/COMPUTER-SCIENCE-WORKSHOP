# Importing necessary libraries
try:
    import cv2 as cv
    import numpy as np
except ImportError as e:
    print(f"Error importing libraries: {e}")
    exit(1)

class Preprocessor:
    def apply_median_blur(self, image, kernel_size=5):
        """
        Apply median blur to the image.
        
        :param image: Input image.
        :param kernel_size: Size of the kernel. Must be odd.
        :return: Image with median blur applied.
        """
        return cv.medianBlur(image, kernel_size)
   
    def apply_threshold(self, image, method=cv.THRESH_BINARY, block_size=11, C=2):
        """
        Apply thresholding to the image.
        
        :param image: Input image.
        :param method: Thresholding method.
        :param block_size: Size of a pixel neighborhood that is used to calculate a threshold value.
        :param C: Constant subtracted from the mean or weighted mean.
        :return: Thresholded image.
        """
        # You can add conditions here to choose between global and adaptive thresholding
        if method in [cv.THRESH_BINARY, cv.THRESH_BINARY_INV, cv.THRESH_TRUNC, cv.THRESH_TOZERO, cv.THRESH_TOZERO_INV]:
            _, thresh = cv.threshold(image, 127, 255, method)
        else:
            thresh = cv.adaptiveThreshold(image, 255, cv.ADAPTIVE_THRESH_MEAN_C, cv.THRESH_BINARY, block_size, C)
        return thresh

# File path for the image
file_path = 'C:\\Users\\tahar\\Downloads\\Screenshot 2024-03-20 at 10.21.14.png'

# Initialize the Preprocessor class
preprocessor = Preprocessor()

try:
    # Reading the image in grayscale
    image = cv.imread(file_path, cv.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"No file found at {file_path}.")

    # Applying median blur
    blurred_image = preprocessor.apply_median_blur(image)

    # Applying thresholding
    thresholded_image = preprocessor.apply_threshold(blurred_image)

    # Display the original and preprocessed images for comparison
    cv.imshow("Original Image", image)
    cv.imshow("Blurred Image", blurred_image)
    cv.imshow("Thresholded Image", thresholded_image)
    cv.waitKey(0)
    cv.destroyAllWindows()
except FileNotFoundError as fnf_error:
    print(fnf_error)
except Exception as e:
    print(f"An unexpected error occurred: {e}")
