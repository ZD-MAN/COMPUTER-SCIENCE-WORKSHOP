# Importing the OpenCV module as cv
import cv2 as cv

# Defining ImageAcquisition class
class ImageAcquisition:
    def read_image(self, file_path):
        # Trying to read the image file
        try:
            image = cv.imread(file_path, 0)
            # Checking if the image was successfully read (image is not None)
            if image is None:
                # If image is None, it means OpenCV did not find the file or could not read it
                raise FileNotFoundError(f"Failed to read the image at {file_path}. Check the file path or file format.")
            return image
        except FileNotFoundError as fnf_error:
            print(fnf_error)
            return None
        except Exception as e:
            # Handling any other exception
            print(f"An unexpected error occurred: {e}")
            return None

# Initializing the ImageAcquisition(IA) class
image_acquisition = ImageAcquisition()

# Defining file path
file_path = 'C:\\Users\\tahar\\Downloads\\Screenshot 2024-03-20 at 10.21.14.png'

try:
    # Reading the image using the read_image method of IA
    image_data = image_acquisition.read_image(file_path)

    if image_data is not None:
        # Displaying the image data/processing
        print("Image read successfully.")
        print(image_data)
    else:
        # If image_data is None, it means there was an error reading the image
        print("Failed to read the image. Check the console for details.")
except Exception as general_error:
    # Handling unexpected errors that could occur outside the read_image method
    print(f"An unexpected error occurred while processing the image: {general_error}")
