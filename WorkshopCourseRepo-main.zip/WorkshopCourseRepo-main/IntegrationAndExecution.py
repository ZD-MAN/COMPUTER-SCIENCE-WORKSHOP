class LicensePlateRecognitionSystem:
    def __init__(self):
        try:
            self.image_acquisition = ImageAcquisition()
            self.preprocessor = Preprocessor()
            self.plate_detector = PlateDetector()
            self.character_segmenter = CharacterSegmenter()
            self.character_recognizer = CharacterRecognizer()
        except Exception as e:
            print(f"An error occurred during initialization: {e}")

    def recognize_plate(self, file_path):
        try:
            # Read the image using image acquisition
            image = self.image_acquisition.read_image(file_path)
            
            # Apply median blur preprocessing
            preprocessed_image = self.preprocessor.apply_median_blur(image)
            
            # Detect plate
            plate_image = self.plate_detector.detect_plate(preprocessed_image)
            
            # Segment characters
            char_images = self.character_segmenter.segment_characters(plate_image)
            
            # Recognize characters
            plate_number = self.character_recognizer.recognize_characters(char_images)
            
            return plate_number
        except Exception as e:
            print(f"An error occurred during plate recognition: {e}")
            return ""

# Example usage:
# Initialize the LicensePlateRecognitionSystem class
lp_recognition_system = LicensePlateRecognitionSystem()

# File path for the image
file_path = "path_to_image.jpg"  # Replace "path_to_image.jpg" with the actual file path

# Perform license plate recognition
try:
    plate_number = lp_recognition_system.recognize_plate(file_path)
    print("Recognized license plate number:", plate_number)
except Exception as e:
    print(f"An error occurred: {e}")
