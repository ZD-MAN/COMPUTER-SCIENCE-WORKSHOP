
try:
    
# Import necessary modules for plotting and image processing

# Matplotlib's pyplot module for plotting
    from matplotlib import pyplot as plt
# Matplotlib's image module for reading images
    from matplotlib import image as mpimg  

# Load the example image from file using Matplotlib's image module
    example_img = mpimg.imread('C:\\Users\\tahar\\Downloads\\Screenshot 2024-03-20 at 10.21.14.png')

# Create a new figure with a specified size using Matplotlib's pyplot module
    fig = plt.figure(figsize=(14, 10))

# Add the first subplot to the figure (1 row, 2 columns, first plot)
    ax1 = fig.add_subplot(1, 2, 1)
# Display the example image in the first subplot
    imgplot1 = ax1.imshow(example_img)
# Set the title of the first subplot
    ax1.set_title('Before')
# Add a color bar to the first subplot (orientation: horizontal)
    fig.colorbar(imgplot1, ax=ax1, orientation='horizontal')

# Add the second subplot to the figure (1 row, 2 columns, second plot)
    ax2 = fig.add_subplot(1, 2, 2)
# Extract the blue channel of the example image
    example_img_blue = example_img[:, :, 2]
# Display the blue channel image in the second subplot with 'Blues' colormap
    imgplot2 = ax2.imshow(example_img_blue, cmap='Blues')
# Set the title of the second subplot
    ax2.set_title('After')
# Add a color bar to the second subplot (orientation: horizontal)
    fig.colorbar(imgplot2, ax=ax2, orientation='horizontal')

# Show the figure with both subplots
    plt.show()

except Exception as e:
    print("An error occurred:", e)
